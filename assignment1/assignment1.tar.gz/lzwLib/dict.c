#include <stdlib.h>
#include <dict.h>

Dict* newDict(unsigned int hashSize) {
    return NULL;
}

void deleteDictDeep(Dict* dict) {
}

bool searchDict(Dict* dict, Sequence* key, unsigned int* code) {
    return false;
}

void insertDict(Dict* dict, Sequence* key, unsigned int code) {
}
